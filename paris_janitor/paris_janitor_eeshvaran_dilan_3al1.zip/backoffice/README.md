npm install

then npm run dev